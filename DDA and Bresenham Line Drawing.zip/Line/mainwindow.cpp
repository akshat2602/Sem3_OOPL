#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "bits/stdc++.h"
QImage img(400,400,QImage::Format_RGB888);

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    int x1,x2,y1,y2,r;
    x1=ui->textEdit->toPlainText().toInt();
    x2=ui->textEdit_2->toPlainText().toInt();
    y1=ui->textEdit_3->toPlainText().toInt();
    y2=ui->textEdit_4->toPlainText().toInt();
    r=ui->textEdit_5->toPlainText().toInt();
    ddaline(x1,y1,x2,y2);
    ui->label_3->setPixmap(QPixmap::fromImage(img));
}



void MainWindow::ddaline(float x1, float y1, float x2, float y2)
{

    ui->label_3->setPixmap(QPixmap::fromImage(img));
    float dx,dy,len,i;
    float x,y,x_inc,y_inc;
    dx = (x2 - x1);
    dy = (y2 - y1);
    if(abs(dx) >= abs(dy))
        len = abs(dx);
    else
        len = abs(dy);
    x_inc = dx / float(len);
    y_inc = dy / float(len);
    x = x1;
    y = y1;
    for(i = 0; i <= len; i++)
    {
        img.setPixel(x,y,qRgb(0,255,0));
        x += x_inc;
        y += y_inc;
    }
}

void MainWindow::circle(int xc, int yc, int r)
{
    int x = 0, y = r;
        int d = 3 - 2 * r;
        drawCircle(xc, yc, x, y);
        while (y >= x)
        {
            // for each pixel we will
            // draw all eight pixels

            x++;

            // check for decision parameter
            // and correspondingly
            // update d, x, y
            if (d > 0)
            {
                y--;
                d = d + 4 * (x - y) + 10;
            }
            else
                d = d + 4 * x + 6;
            drawCircle(xc, yc, x, y);
        }
}

void MainWindow::drawCircle(int xc, int yc, int x, int y)
{
    img.setPixel(xc+x, yc+y, qRgb(0,255,0));
    img.setPixel(xc-x, yc+y, qRgb(0,255,0));
    img.setPixel(xc+x, yc-y, qRgb(0,255,0));
    img.setPixel(xc-x, yc-y, qRgb(0,255,0));
    img.setPixel(xc+y, yc+x, qRgb(0,255,0));
    img.setPixel(xc-y, yc+x, qRgb(0,255,0));
    img.setPixel(xc+y, yc-x, qRgb(0,255,0));
    img.setPixel(xc-y, yc-x, qRgb(0,255,0));
}

void MainWindow::triangle(int x1,int y1,int x2,int y2,int x3,int y3){
    ddaline(x1,y1,x2,y2);
    ddaline(x2,y2,x3,y3);
    ddaline(x3,y3,x1,y1);
}

void MainWindow::on_pushButton_2_clicked()
{   int x1,y1,x2,y2,x3,y3,xc1,yc1,xc2,yc2,r1,r2;
    xc1=ui->textEdit_9->toPlainText().toInt();
    yc1=ui->textEdit_10->toPlainText().toInt();
    r1=ui->textEdit_5->toPlainText().toInt();
    xc2=ui->textEdit_11->toPlainText().toInt();
    yc2=ui->textEdit_12->toPlainText().toInt();
    r2=ui->textEdit_6->toPlainText().toInt();
    x1=ui->textEdit->toPlainText().toInt();
    y1=ui->textEdit_3->toPlainText().toInt();
    x2=ui->textEdit_2->toPlainText().toInt();
    y2=ui->textEdit_4->toPlainText().toInt();
    x3=ui->textEdit_7->toPlainText().toInt();
    y3=ui->textEdit_8->toPlainText().toInt();
    circle(xc1,yc1,r1);
    triangle(x1,y1,x2,y2,x3,y3);
    circle(xc2,yc2,r2);
    ui->label->setPixmap(QPixmap::fromImage(img));
}

