#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <ostream>
#include<QMouseEvent>
#include<QMessageBox>
using namespace std;

QImage img(700,700,QImage::Format_RGB888);
QColor c=qRgb(170, 255, 255);
int vertices=0,temp,i,j,x_vertex[20],y_vertex[20];
float slope_inverse[20],dx,dy,xi[20];
bool start=true;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


//check if point lies within the output label
bool MainWindow::limit_error(int a,int b){
    if(a>=0 && a<=700 && b>=0 && b<=700){
        return true;
    }
    else{
        return false;
    }
};

//dda line drawing algorithm
void MainWindow::dda_line(int x1,int y1,int x2,int y2)
{
    float dx,dy,length,x,y;
    dx=x2-x1;
    dy=y2-y1;
    x=x1;
    y=y1;
    if(abs(dx)>abs(dy)){
        length=abs(dx);
    }
    else{
        length=abs(dy);
    }
    dx=dx/length;
    dy=dy/length;
    int i=0;
    while(i<=length){
        img.setPixel(x,y,c.rgb());
        x+=dx;
        y+=dy;
        i++;
    }
    ui->outputScreen->setPixmap((QPixmap::fromImage(img)));
}

//mouse press on output label is takes as the vertex of the polygon
void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if (start){
        int p = ev->pos().x();
        int q = ev->pos().y();
        if(limit_error(p,q)){
            x_vertex[vertices] = p;
            y_vertex[vertices] = q;
            if (ev->button() == Qt::RightButton){
                dda_line(x_vertex[0], y_vertex[0], x_vertex[vertices - 1], y_vertex[vertices - 1]);
                start = false;
            }
            else{
                if (vertices > 0){
                    dda_line(x_vertex[vertices - 1], y_vertex[vertices - 1], x_vertex[vertices], y_vertex[vertices]);
                }
            }
            vertices++;
        }
        else{
            QMessageBox exception;
            exception.critical(0,"Not within the limit","Enter Integer Value inside the screen");
            exception.setFixedSize(600,300);
            exception.exec();
        }

    }
}

//select the color of polygon to be filled
void MainWindow::on_color_select_button_clicked()
{
    c = QColorDialog::getColor(Qt::white);
}

//scan fill algorithm
void MainWindow::on_scan_fill_button_clicked()
{
    if (vertices>3){
        x_vertex[vertices]=x_vertex[0];
        y_vertex[vertices]=y_vertex[0];
        for(i=0;i<vertices;i++){
            dx=x_vertex[i+1]-x_vertex[i];
            dy=y_vertex[i+1]-y_vertex[i];

            //array of slopes
            if(dx==0.0){slope_inverse[i]=1.0;}
            if(dy==0.0){slope_inverse[i]=0.0;}
            if(dx!=0.0 and dy!=0.0){
                slope_inverse[i]=dx/dy;
            }
        }

        //array of x values
        for(int y=0;y<700;y++){
            int index=0;
            for(i=0;i<vertices;i++){
                if((y>=y_vertex[i] and y<y_vertex[i+1])or(y>=y_vertex[i+1] and y<y_vertex[i])){
                    xi[index]=x_vertex[i]+(slope_inverse[i]*(y-y_vertex[i]));
                    index++;
                }
            }
            //bubblesort
            for(i=0;i<vertices-1;i++){
                for(j=0;j<vertices-1-i;j++){
                    if(xi[j]>xi[j+1]){
                        temp=xi[j];
                        xi[j]=xi[j+1];
                        xi[j+1]=temp;
                    }
                }
            }
            //calling line drawing algorithm
            for(j=0;j<index;j+=2){
                dda_line(xi[j],y,xi[j+1],y);
            }
        }
    }
    else{
        QMessageBox exception;
        exception.critical(0,"Not a polygon","Line is not a polygon");
        exception.setFixedSize(600,300);
        exception.exec();
    }

}

//clears the output label
void MainWindow::on_clear_button_clicked()
{
    for(i=0;i<=vertices;i++){
        x_vertex[i]=0;
        y_vertex[i]=0;
    }
    vertices=0;
    QImage* newImage=new QImage(700,700,QImage::Format_RGB888);
    img=*newImage;
    ui->outputScreen->setPixmap((QPixmap::fromImage(img)));
    start=true;
}
